<div align='center'>
  
# Changelog
</div>

### 9/2/2023
- Added Chess (By Mecharis)
- Added Subway Surfers (By Mecharis)
### 8/28/2023
- Changed UV Prefix to `/students/lesson`
### 8/27/2023
- Tab Cloaking now opens up as a normal tab, parent tab redirects to Google Classroom.
- Small CSS Updates
- Changed placeholder on proxy input
### 8/5/2023
- Added loading screen for Apps & Games
- Added Now.GG to Apps section (Should it be Games or Apps???)
- Added Pinterest
### 8/4/2023
- Added search bar for Apps & Games section
- Updated page background
- Updated font
- CSS/UI updates
### 8/3/2023
- Added Roblox (Finally!!)
- Tab title updates
- Apps & Games page updates
### 7/22/2023
- Added Jstris (Tetris)
### 7/19/2023
- Cleaned up useless dependencies
### 7/16/2023
- Updated login page (more security)
### 7/14/2023
- Added more options to the login page (You can now enable or disable it through the right click menu)
- Updated right click menu
### 7/13/2023
- Implemented a login page
### 7/8/2023
- Added "Enable" and "Disable" buttons for Tab Cloaking (in right click menu)
### 7/7/2023
- Fixed Apps & Games
- Fixed glitchy buttons
- Added Credits Page (By [Russell2259](https://github.com/Russell2259))
- Updated Tab Cloaking to cloak Google Drive
### 7/3/2023
- Updated Backend to [Easyviolet](https://github.com/Russell2259/Easyviolet) (By [Russell2259](https://github.com/Russell2259))
- Cleaned up files (By [Russell2259](https://github.com/Russell2259))
### 7/2/2023
- Added Tab Cloaking
- Added right click menu (moved `about:blank` cloak there)
- Updated Backend (By [Russell2259](https://github.com/Russell2259))
### 7/1/2023
- Updated Slope link in Games section
- Small HTML fixes
- Updated broken background on loading screen
- Changed loading icon on loading screen
- Removed Cancel button on loading screen
### 6/30/2023
- Added Railway deployment method
- Removed Ultraviolet dependency in package.json to prevent detection
### 6/29/2023
- Renamed public directory to "static"
- Fixed package.json
- Fixed bare server bug
### 6/23/2023
- Fixed buttons on games section
### 6/22/2023
- Updated Bare Server
- Updated Dockerfile (for Back4app deployment)
- Redesigned Homepage (https://dogenetwork.uk.ms)
- Updated 404 Page
