/*
@Russell2259 removed this cause it was annoying. we can add it as a setting

window.onbeforeunload = function(e) {  return "Do you want to exit this page?";};
console.log("leaveConfirmation.js activated.");
*/